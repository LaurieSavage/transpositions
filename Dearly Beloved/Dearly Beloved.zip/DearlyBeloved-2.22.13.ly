\version "2.23.13"

\include "AccordsJazzDefs.ily"
\include "LilyJAZZ.ily"

\paper {
  top-margin = 15\mm
  left-margin = 20\mm
  right-margin = 20\mm
  bottom-margin = 10\mm
   #(define fonts
     (set-global-fonts
      #:roman "LilyJAZZ Text"
      #:sans "Nimbus Sans, Nimbus Sans L"
      #:typewriter "DejaVu Sans Mono"
      ; unnecessary if the staff size is default
      #:factor (/ staff-height pt 20)
      ))
}

layoutScore = \layout {
  indent = 15\mm
}

today = #(strftime "%d-%m-%Y" (localtime (current-time)))

comp = #(define-music-function (parser location count) ( integer?)
          #{
            \override Rest #'stencil = #ly:percent-repeat-interface::beat-slash
            \override Rest #'thickness = #0.48
            \override Rest #'slope = #1.7
            \repeat unfold $count { r4 }
            \revert Rest #'stencil
          #}
          )

\header {
  title = "Dearly Beloved"
  subtitle = "Male Key"
  composer = "Jerome Kern"
  poet = "Johnny Mercer"
  piece = "Med. swing"
  %tagline = \markup{\small \italic {"Edited by L.S. " \today}}
  copyright = "1942"
}

\include "lyrics.ly"
\include "tune.ly"
\include "chords.ly"

\book {
  \bookOutputSuffix "C"
  \header {
    instrument = "C instruments"
  }
  \score {
    <<
      \new ChordNames \chordNames
      \new Staff {
        \melody 
      }
      \addlyrics \verses
    >>
    \layoutScore
  }
}

\book {
  \bookOutputSuffix "Bflat"
  \header {
    instrument = "Tenor Sax/Trumpet"
  }
  \score {
    <<
      \new ChordNames \transpose bes c \chordNames
      \new Staff \transpose bes c' \melody
      \addlyrics \verses
    >>
    \layoutScore
  }
}

\book {
  \bookOutputSuffix "Eflat"
  \header {
    instrument = "Baritone/Alto Sax"
  }
  \score {
    <<
      \new ChordNames \transpose ees c \chordNames
      \new Staff \with { instrumentName = \markup{ "E"\flat " Sax" }} \transpose ees c' \melody
      %\addlyrics \verses
    >>
    \layoutScore
  }
}

\book {
  \bookOutputSuffix "Fl"
  \header {
    instrument = "Flute"
  }
  \paper {
    #(set-paper-size "a4landscape")
  }
  \score {
    <<
      \new ChordNames \chordNames
      \new Staff \with { instrumentName = "Flute" } \transpose c c' \melody
    >>
    \layout {
      #(layout-set-staff-size 14)
    }
  }
}


%{
convert-ly (GNU LilyPond) 2.23.13  convert-ly: Processing `'...
Applying conversion: 2.21.0, 2.21.2, 2.23.1, 2.23.2, 2.23.3, 2.23.4,
2.23.5, 2.23.6, 2.23.7, 2.23.8, 2.23.9, 2.23.10, 2.23.11, 2.23.12,
2.23.13
%}
